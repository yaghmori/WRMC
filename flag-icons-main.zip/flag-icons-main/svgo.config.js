module.exports = {
  plugins: [
    {
      name: "preset-default",
    },
    "convertStyleToAttrs",
    "removeDimensions",
    "removeScriptElement",
    "removeStyleElement",
    "sortAttrs",
  ],
};
